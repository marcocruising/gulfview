This README describes the contents of the ZIP file:

1. Spreadsheet files

   a) All research results across all mines:
   
        Coal Mine Boundaries and Methane Sources - version #.#.# (built on <build date>)).xlsx
      
   b) Research results for each mine:

        <mine name>.xlsx

2. GeoJSON files

   a) All research results across all mines:

        Coal Mine Boundaries and Methane Sources - version #.#.# (built on <build date>)).geojson

   b) Research results for each mine:

        <mine name>.geojson

Please contact dominic.nicholas@globalenergymonitor.org with any questions, suggestions or feedback.

Thanks

